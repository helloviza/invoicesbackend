// Alias: /invoices/new -> existing InvoicePage
export { default } from "../InvoicePage";
export * from "../InvoicePage";
